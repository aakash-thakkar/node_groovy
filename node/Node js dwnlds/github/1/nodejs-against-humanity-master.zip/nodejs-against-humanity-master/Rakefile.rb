task :server do
  sh "\"c:\\Program Files (x86)\\nodejs\\node.exe\" server.js"
end

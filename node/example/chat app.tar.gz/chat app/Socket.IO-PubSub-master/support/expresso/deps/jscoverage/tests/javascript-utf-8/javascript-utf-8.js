var s = 'eèéê';
var r = /eèéê/;

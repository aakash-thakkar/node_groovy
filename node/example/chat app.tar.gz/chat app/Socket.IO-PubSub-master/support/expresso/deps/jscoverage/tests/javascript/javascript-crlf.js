/*
This file has CRLF line endings.
*/
var x = 1;

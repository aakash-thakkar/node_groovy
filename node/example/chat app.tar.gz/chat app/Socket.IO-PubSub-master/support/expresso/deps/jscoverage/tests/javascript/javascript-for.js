for (i in x) {
  x();
}

for (var i in x) {
  x();
}

for (i = 0; i < x; i++) {
  x();
}

for (var j = 0; j < x; j++) {
  x();
}

for (i in x)
  x();

for (i.value in x) {
  x();
}

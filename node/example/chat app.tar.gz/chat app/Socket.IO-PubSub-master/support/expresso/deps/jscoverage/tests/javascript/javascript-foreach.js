/*
https://developer.mozilla.org/en/Core_JavaScript_1.5_Guide/Object_Manipulation_Statements
https://developer.mozilla.org/en/Core_JavaScript_1.5_Reference/Statements/for_each...in
*/

for each (var item in obj) {
  sum += item;
}

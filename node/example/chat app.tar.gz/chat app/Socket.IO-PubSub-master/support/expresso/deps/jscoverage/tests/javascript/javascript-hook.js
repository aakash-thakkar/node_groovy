var x = 1;
var y = x === 1? "x": "y";

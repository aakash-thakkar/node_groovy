function X() {}
x = new X();
x = new X(1);
x = new X(1, 2);

x = a + (b - c);

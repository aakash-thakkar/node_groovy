function f() {
	return '\'';
}

function g() {
	return "\"";
}

function h() {
	return '\\';
}

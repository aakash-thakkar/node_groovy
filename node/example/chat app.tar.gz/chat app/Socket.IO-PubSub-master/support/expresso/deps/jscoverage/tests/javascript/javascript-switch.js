switch (x) {
case x:
  x = 0;
  break;
case y:
  x = 0;
  y = 0;
  break;
default:
  x = 0;
  break;
}

switch (x) {
case 1:
  let y = 1;
  f(y);
  break;
case 2:
  break;
}

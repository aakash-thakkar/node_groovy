try {
  throw "x";
}
catch (e) {
  ;
}

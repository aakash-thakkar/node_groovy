x = -x;
x = +x;
x = !x;
x = ~x;
x = typeof x;
x = void x;
